/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2008, PostgreSQL Global Development Group
*
* IDENTIFICATION
*   $PostgreSQL: pgjdbc/org/postgresql/jdbc3/Jdbc3SimpleDataSource.java,v 1.6 2008/01/08 06:56:29 jurka Exp $
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc3;

import org.postgresql.ds.PGSimpleDataSource;

public class Jdbc3SimpleDataSource extends PGSimpleDataSource
{
}
