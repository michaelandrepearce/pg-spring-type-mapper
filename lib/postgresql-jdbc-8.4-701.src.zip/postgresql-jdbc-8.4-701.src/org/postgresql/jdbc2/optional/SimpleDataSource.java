/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2008, PostgreSQL Global Development Group
*
* IDENTIFICATION
*   $PostgreSQL: pgjdbc/org/postgresql/jdbc2/optional/SimpleDataSource.java,v 1.6 2008/01/08 06:56:29 jurka Exp $
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc2.optional;

import org.postgresql.ds.PGSimpleDataSource;

public class SimpleDataSource extends PGSimpleDataSource
{
}
